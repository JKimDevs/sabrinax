import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Achievements } from "./components/Achievements";
import { Creative } from "./components/Creative";
import { Family } from "./components/Family";
import { StudentLife } from "./components/StudentLife";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <main>
        <Hero />
        <About />
        <section id="achievements">
          <Achievements />
        </section>
        <section id="creative">
          <Creative />
        </section>
        <section id="family">
          <Family />
        </section>
        <section id="student">
          <StudentLife />
        </section>
        <Contact />
      </main>
      <Footer />
    </div>
  );
}