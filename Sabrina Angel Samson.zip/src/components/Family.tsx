import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Family() {
  const familyMembers = [
    {
      name: "Ella",
      role: "Mom",
      description: "Dedicated housewife and former running trainer",
      location: "United States",
      icon: "👩"
    },
    {
      name: "Joe",
      role: "Stepdad",
      description: "Works at IBM and former running trainer",
      location: "United States",
      icon: "👨"
    },
    {
      name: "Janieya",
      role: "Sister",
      description: "Works at Optum",
      location: "United States",
      icon: "👩‍💼"
    },
    {
      name: "Federico",
      role: "Grandfather",
      description: "My current guardian and support system",
      location: "Philippines",
      icon: "👴"
    }
  ];

  return (
    <section className="py-20 px-4 bg-secondary/10">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">My Family</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A loving family that spans continents, united by shared passions and unbreakable bonds
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="space-y-6">
            <div className="space-y-4">
              <h3>Our Journey Together</h3>
              <p className="text-muted-foreground leading-relaxed">
                My family story is one of love, support, and shared adventures. Though we're 
                currently separated by oceans—with my parents and sister in the United States 
                while I stay in the Philippines with my grandfather—our bonds remain stronger than ever.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                We began as a family of runners, with my parents serving as our dedicated trainers 
                for long-distance races. Those early morning training sessions and race day celebrations 
                created memories that continue to inspire me today.
              </p>
            </div>
            
            <div className="space-y-4">
              <h4>From Running to Traveling</h4>
              <p className="text-muted-foreground leading-relaxed">
                Now that we've all stepped back from competitive racing, our shared passion has 
                evolved into exploring the world together. Family trips have become our new races—
                adventures where we create new stories and strengthen our connections across distances.
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Badge>Family Unity</Badge>
              <Badge>Cross-Continental Love</Badge>
              <Badge>Shared Adventures</Badge>
              <Badge>Supportive Network</Badge>
            </div>
          </div>
          
          <div className="flex justify-center">
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1659662555007-5c2e1f4cf39f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjB0cmF2ZWwlMjBhaXJwbGFuZSUyMHZhY2F0aW9ufGVufDF8fHx8MTc1OTIzOTIxMHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Family travel and togetherness"
                className="w-full max-w-md h-80 object-cover rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-full shadow-lg">
                ✈️ Travel Together
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {familyMembers.map((member, index) => (
            <Card key={index} className="p-6 space-y-4 text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-2xl mx-auto">
                {member.icon}
              </div>
              
              <div className="space-y-2">
                <h3>{member.name}</h3>
                <Badge variant="outline" className="mb-2">{member.role}</Badge>
                <p className="text-muted-foreground text-sm">{member.description}</p>
              </div>
              
              <div className="pt-2 border-t border-border">
                <p className="text-xs text-muted-foreground">
                  📍 {member.location}
                </p>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg p-8 max-w-4xl mx-auto">
          <div className="text-center space-y-4">
            <h3 className="text-xl">Living with Grandpa Federico</h3>
            <p className="text-muted-foreground leading-relaxed">
              While my parents and sister pursue their careers in the United States, I'm blessed 
              to live with my grandfather Federico here in the Philippines. This arrangement has 
              taught me independence, responsibility, and the value of intergenerational wisdom. 
              Grandpa Federico provides not just a home, but guidance, stories, and the steady 
              presence that keeps me grounded while I pursue my studies and dreams.
            </p>
            <div className="flex justify-center pt-4">
              <Badge variant="secondary">🏠 Home Base: Philippines</Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}