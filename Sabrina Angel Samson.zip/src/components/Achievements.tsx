import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Achievements() {
  const sprintAchievements = [
    {
      title: "Gold Medal - 100m Sprint",
      description: "Champion in the 100 meter sprint event",
      year: "2017",
      icon: "🥇",
      category: "Sprint"
    },
    {
      title: "Gold Medal - 200m Sprint",
      description: "First place in the 200 meter sprint event",
      year: "2017",
      icon: "🥇",
      category: "Sprint"
    },
    {
      title: "Silver Medal - 400m Relay",
      description: "Second place in the 400m relay team event",
      year: "2017",
      icon: "🥈",
      category: "Sprint Relay"
    }
  ];

  const distanceAchievements = [
    {
      title: "First 10km Trophy",
      description: "Earned my first trophy in long-distance racing",
      year: "2018",
      icon: "🏆",
      category: "Long Distance Debut"
    },
    {
      title: "Half Marathon - 2 Hour Finish",
      description: "Completed 21km half-marathon in just 2 hours",
      year: "Recent",
      icon: "🏃‍♀️",
      category: "Personal Best"
    },
    {
      title: "Multiple Medal Collection",
      description: "Accumulated many medals across various distances",
      year: "2018-Present",
      icon: "🏅",
      category: "Consistent Excellence"
    }
  ];

  return (
    <section className="py-20 px-4 bg-secondary/20">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Athletic Achievements</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            My running journey has been marked by dedication, family support, and memorable accomplishments
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="space-y-8">
            <div className="space-y-4">
              <h3>My Athletic Evolution</h3>
              <p className="text-muted-foreground leading-relaxed">
                I had a great running career that began in 2017 as a sprinter, where I achieved 
                remarkable success with gold medals in both the 100m and 200m events, plus a 
                silver medal in the 400m relay. This early success laid the foundation for my 
                athletic journey.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                After mastering the sprint distances, I transitioned to marathon running, earning 
                my first trophy in a 10km race in 2018. From there, I continued collecting medals 
                across various distances, with my longest achievement being a 21km half-marathon 
                that I completed in just two hours.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Though academics led me to step back from competitive racing, the discipline and 
                achievements from both sprinting and distance running continue to shape my approach 
                to every challenge I face today.
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Badge>Sprint Champion</Badge>
              <Badge>Distance Runner</Badge>
              <Badge>Gold Medalist</Badge>
              <Badge>Sub-2 Hour Half Marathon</Badge>
            </div>
          </div>
          
          <div className="flex justify-center">
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1758684051112-3df152ce3256?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwcnVubmVyJTIwbWFyYXRob24lMjBmaW5pc2glMjBsaW5lfGVufDF8fHx8MTc1OTIzOTIwOXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Running achievement"
                className="w-full max-w-md h-80 object-cover rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-full shadow-lg">
                🏃‍♀️ Sprint to Marathon
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-12">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-2xl mb-4">Sprint Career (2017)</h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                My athletic journey began with explosive sprint performances, earning gold medals and establishing my competitive foundation
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sprintAchievements.map((achievement, index) => (
                <Card key={index} className="p-6 space-y-4 hover:shadow-lg transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-xl">
                      {achievement.icon}
                    </div>
                    <Badge variant="outline">{achievement.category}</Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <h4>{achievement.title}</h4>
                    <p className="text-muted-foreground text-sm">{achievement.description}</p>
                  </div>
                  
                  <div className="pt-2 border-t border-border">
                    <p className="text-sm text-muted-foreground">
                      Year: <span className="text-primary">{achievement.year}</span>
                    </p>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-2xl mb-4">Distance Running Evolution (2018-Present)</h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Transitioning to longer distances brought new challenges and remarkable achievements, including my impressive 2-hour half marathon
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {distanceAchievements.map((achievement, index) => (
                <Card key={index} className="p-6 space-y-4 hover:shadow-lg transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center text-xl">
                      {achievement.icon}
                    </div>
                    <Badge variant="secondary">{achievement.category}</Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <h4>{achievement.title}</h4>
                    <p className="text-muted-foreground text-sm">{achievement.description}</p>
                  </div>
                  
                  <div className="pt-2 border-t border-border">
                    <p className="text-sm text-muted-foreground">
                      Period: <span className="text-primary">{achievement.year}</span>
                    </p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
        
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary/5 to-secondary/10 rounded-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-xl mb-4">Athletic Legacy</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              From sprinting gold medals to marathon endurance, my athletic journey spans multiple disciplines 
              and years of dedicated training. Each race, whether a 100m sprint or a 21km half-marathon, 
              taught me valuable lessons about perseverance, goal-setting, and pushing beyond limits.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              "The discipline and knowledge from my athletic past flows into everything I do as a student today. 
              Every finish line crossed—from my first gold medal to that 2-hour half marathon—has prepared 
              me for the challenges ahead."
            </p>
            <div className="flex justify-center flex-wrap gap-2 mt-6">
              <Badge variant="secondary">🥇 Multiple Gold Medals</Badge>
              <Badge variant="secondary">🏃‍♀️ 2-Hour Half Marathon</Badge>
              <Badge variant="secondary">🏆 First Trophy 2018</Badge>
              <Badge variant="secondary">📈 Sprint to Distance Evolution</Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}