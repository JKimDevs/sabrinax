import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

export function Contact() {
  const connectionPoints = [
    {
      title: "Academic Collaboration",
      description: "Connect for study groups, academic projects, or student initiatives",
      icon: "🎓",
      action: "Study Together"
    },
    {
      title: "Creative Projects",
      description: "Collaborate on artistic endeavors, creative expression, or cultural events",
      icon: "🎨",
      action: "Create Together"
    },
    {
      title: "Running Community",
      description: "Join for running sessions, athletic events, or fitness motivation",
      icon: "🏃‍♀️",
      action: "Run Together"
    },
    {
      title: "Cultural Exchange",
      description: "Share experiences about Philippines-US family connections",
      icon: "🌏",
      action: "Share Stories"
    }
  ];

  return (
    <section id="contact" className="py-20 px-4 bg-primary/5">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Let's Connect</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Whether you're interested in academics, arts, athletics, or just sharing stories, 
            I'd love to hear from you
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
          <div className="space-y-6">
            <div className="space-y-4">
              <h3>About Connecting With Me</h3>
              <p className="text-muted-foreground leading-relaxed">
                I'm always excited to meet new people who share similar interests or who can 
                introduce me to new perspectives. As someone who values both individual growth 
                and community connection, I believe the best experiences come from meaningful 
                interactions with others.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Whether you're a fellow student in Lucena City, someone with a passion for 
                running and athletics, a creative soul interested in the arts, or simply someone 
                who enjoys good conversation about life, family, and dreams—I'd love to connect.
              </p>
            </div>
            
            <div className="space-y-4">
              <h4>What I Value in Connections</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-primary">✓</span>
                  <span className="text-muted-foreground">Authentic conversations and shared experiences</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-primary">✓</span>
                  <span className="text-muted-foreground">Learning from different perspectives and backgrounds</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-primary">✓</span>
                  <span className="text-muted-foreground">Supporting each other's goals and aspirations</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-primary">✓</span>
                  <span className="text-muted-foreground">Building lasting friendships based on mutual respect</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <Card className="p-6 space-y-4">
              <h4>Current Focus Areas</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">📚 Academic Studies</span>
                  <Badge variant="outline">Active</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">🎨 Creative Projects</span>
                  <Badge variant="outline">Available</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">🏃‍♀️ Running Activities</span>
                  <Badge variant="outline">Open</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">✈️ Family Travel Planning</span>
                  <Badge variant="outline">Ongoing</Badge>
                </div>
              </div>
            </Card>
            
            <Card className="p-6 space-y-4">
              <h4>Location & Availability</h4>
              <div className="space-y-2">
                <p className="text-muted-foreground">
                  <span className="text-primary">📍 Based in:</span> Lucena City, Philippines
                </p>
                <p className="text-muted-foreground">
                  <span className="text-primary">🕒 Best time:</span> Weekdays and weekends
                </p>
                <p className="text-muted-foreground">
                  <span className="text-primary">🌐 Languages:</span> English, Filipino
                </p>
              </div>
            </Card>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {connectionPoints.map((point, index) => (
            <Card key={index} className="p-6 space-y-4 text-center hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-xl mx-auto">
                {point.icon}
              </div>
              
              <div className="space-y-2">
                <h4>{point.title}</h4>
                <p className="text-muted-foreground text-sm">{point.description}</p>
              </div>
              
              <Badge variant="secondary" className="text-xs">
                {point.action}
              </Badge>
            </Card>
          ))}
        </div>
        
        <div className="text-center space-y-6">
          <div className="bg-white/50 rounded-lg p-8 max-w-2xl mx-auto">
            <h3 className="text-xl mb-4">Ready to Connect?</h3>
            <p className="text-muted-foreground mb-6">
              I'm always open to new connections and conversations. Whether you want to discuss 
              academics, share creative ideas, plan a running session, or simply chat about 
              life experiences, feel free to reach out!
            </p>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Currently available for local meetups in Lucena City and virtual conversations
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                <Badge>Student Collaborations</Badge>
                <Badge>Creative Partnerships</Badge>
                <Badge>Running Buddies</Badge>
                <Badge>Cultural Exchange</Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}