import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function StudentLife() {
  const studentAspects = [
    {
      title: "Academic Pursuit",
      description: "Bringing athletic discipline to my studies",
      icon: "📚",
      highlights: ["Disciplined Study Habits", "Goal-Oriented Learning", "Academic Excellence"]
    },
    {
      title: "Life in Lucena City",
      description: "Embracing student life in my hometown",
      icon: "🏙️",
      highlights: ["Local Community", "Cultural Roots", "City Campus Life"]
    },
    {
      title: "Balanced Lifestyle",
      description: "Integrating athletics, arts, and academics",
      icon: "⚖️",
      highlights: ["Time Management", "Holistic Growth", "Well-rounded Development"]
    }
  ];

  return (
    <section className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Student Life</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Applying the discipline of athletics to academic excellence in Lucena City
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="flex justify-center lg:justify-start">
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBib29rcyUyMGNhbXB1c3xlbnwxfHx8fDE3NTkyMzkyMTB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Student studying with books"
                className="w-full max-w-md h-80 object-cover rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-full shadow-lg">
                📖 Student Life
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="space-y-4">
              <h3>Academic Journey</h3>
              <p className="text-muted-foreground leading-relaxed">
                As a 21-year-old student in Lucena City, I bring the same dedication I once applied 
                to competitive running into my academic pursuits. The discipline learned from early 
                morning training sessions and the perseverance developed through long-distance races 
                now fuel my commitment to learning and personal growth.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Though academics led me to step back from competitive racing, the transition has 
                been natural. The goal-setting skills, time management abilities, and mental 
                resilience developed through athletics serve me well in the classroom and beyond.
              </p>
            </div>
            
            <div className="space-y-4">
              <h4>Living Independently</h4>
              <p className="text-muted-foreground leading-relaxed">
                Living with my grandfather Federico while pursuing my studies has taught me valuable 
                life skills. This arrangement provides the perfect balance of independence and support, 
                allowing me to focus on my education while staying connected to family wisdom and guidance.
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Badge>Academic Excellence</Badge>
              <Badge>Independent Living</Badge>
              <Badge>Time Management</Badge>
              <Badge>Goal-Oriented</Badge>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {studentAspects.map((aspect, index) => (
            <Card key={index} className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-xl">
                {aspect.icon}
              </div>
              
              <div className="space-y-2">
                <h3>{aspect.title}</h3>
                <p className="text-muted-foreground">{aspect.description}</p>
              </div>
              
              <div className="space-y-3 pt-2 border-t border-border">
                <p className="text-sm font-medium">Key Aspects:</p>
                <div className="space-y-1">
                  {aspect.highlights.map((highlight, highlightIndex) => (
                    <Badge key={highlightIndex} variant="secondary" className="text-xs mr-2 mb-1">
                      {highlight}
                    </Badge>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="bg-gradient-to-r from-secondary/10 to-primary/5 rounded-lg p-8 max-w-4xl mx-auto">
          <div className="text-center space-y-4">
            <h3 className="text-xl">The Athletic-Academic Connection</h3>
            <p className="text-muted-foreground leading-relaxed">
              "I bring the discipline and knowledge from my athletic past into everything I do as a student today." 
              This philosophy guides my approach to education, where every assignment is like training for a race, 
              every exam is like a competition, and every semester is like preparing for a marathon. 
              The endurance, focus, and determination that carried me across finish lines now carry me 
              through academic challenges and toward my future goals.
            </p>
            <div className="flex justify-center pt-4 space-x-2">
              <Badge variant="outline">🏃‍♀️ Athletic Discipline</Badge>
              <Badge variant="outline">📚 Academic Excellence</Badge>
              <Badge variant="outline">🎯 Future-Focused</Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}