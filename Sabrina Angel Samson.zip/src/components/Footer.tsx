import { Badge } from "./ui/badge";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <h4>About Sabrina</h4>
            <p className="text-primary-foreground/80 text-sm">
              A 21-year-old student, artist, and runner from Lucena City, Philippines, 
              balancing academics with creative pursuits and family connections.
            </p>
          </div>
          
          <div className="space-y-4">
            <h4>Interests</h4>
            <div className="space-y-2 text-sm">
              <p className="text-primary-foreground/80">🏃‍♀️ Long-distance running</p>
              <p className="text-primary-foreground/80">🎨 Sketching & drawing</p>
              <p className="text-primary-foreground/80">🎤 Singing & dancing</p>
              <p className="text-primary-foreground/80">📚 Academic excellence</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4>Achievements</h4>
            <div className="space-y-2 text-sm">
              <p className="text-primary-foreground/80">🥉 3rd place - 10km run</p>
              <p className="text-primary-foreground/80">🏃‍♀️ Half-marathon finisher</p>
              <p className="text-primary-foreground/80">🎓 Current student</p>
              <p className="text-primary-foreground/80">🎨 Multi-talented artist</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4>Family</h4>
            <div className="space-y-2 text-sm">
              <p className="text-primary-foreground/80">🇵🇭 Based in Philippines</p>
              <p className="text-primary-foreground/80">🇺🇸 Family in USA</p>
              <p className="text-primary-foreground/80">👴 Living with Grandpa Federico</p>
              <p className="text-primary-foreground/80">✈️ Love traveling together</p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary-foreground/20 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <p className="text-sm text-primary-foreground/80">
                Sabrina • Student • Artist • Runner
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="bg-primary-foreground/10 text-primary-foreground border-primary-foreground/20">
                Lucena City
              </Badge>
              <Badge variant="secondary" className="bg-primary-foreground/10 text-primary-foreground border-primary-foreground/20">
                Philippines
              </Badge>
              <Badge variant="secondary" className="bg-primary-foreground/10 text-primary-foreground border-primary-foreground/20">
                Class of 2025
              </Badge>
            </div>
          </div>
          
          <div className="text-center pt-6">
            <p className="text-sm text-primary-foreground/60">
              "I bring the discipline and knowledge from my athletic past into everything I do as a student today."
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}