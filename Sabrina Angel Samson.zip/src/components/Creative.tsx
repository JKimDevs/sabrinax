import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Creative() {
  const creativeInterests = [
    {
      title: "Sketching & Drawing",
      description: "Bringing ideas to life through pencil and paper",
      icon: "✏️",
      skills: ["Portrait Drawing", "Landscape Sketching", "Character Design"]
    },
    {
      title: "Singing",
      description: "Expressing emotions through melody and voice",
      icon: "🎤",
      skills: ["Vocal Performance", "Song Interpretation", "Harmony"]
    },
    {
      title: "Dancing",
      description: "Moving to rhythm with grace and creativity",
      icon: "💃",
      skills: ["Contemporary", "Folk Dance", "Choreography"]
    }
  ];

  return (
    <section className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Creative Pursuits</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            My artistic side flourishes through various forms of creative expression
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="flex justify-center lg:justify-start">
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1758521232708-d738b0eaa94a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnQlMjBzdXBwbGllcyUyMHNrZXRjaGluZyUyMGRyYXdpbmclMjBjcmVhdGl2ZXxlbnwxfHx8fDE3NTkyMzkyMTB8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Art supplies and creative work"
                className="w-full max-w-md h-80 object-cover rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-full shadow-lg">
                🎨 Creative Soul
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="space-y-4">
              <h3>Artistic Expression</h3>
              <p className="text-muted-foreground leading-relaxed">
                Creativity flows through my veins just as much as my love for running. 
                I find joy and peace in various forms of artistic expression, each offering 
                a unique way to communicate emotions and ideas.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Whether it's capturing a moment through sketching, conveying feelings through song, 
                or expressing stories through dance, each creative pursuit adds depth to my 
                understanding of the world and myself.
              </p>
            </div>
            
            <div className="space-y-4">
              <h4>Creative Philosophy</h4>
              <p className="text-muted-foreground leading-relaxed">
                I believe that creativity and athletics complement each other beautifully. 
                The discipline from running enhances my artistic focus, while creative 
                expression brings joy and balance to my structured training mindset.
              </p>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {creativeInterests.map((interest, index) => (
            <Card key={index} className="p-6 space-y-4 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center text-xl">
                {interest.icon}
              </div>
              
              <div className="space-y-2">
                <h3>{interest.title}</h3>
                <p className="text-muted-foreground">{interest.description}</p>
              </div>
              
              <div className="space-y-3 pt-2 border-t border-border">
                <p className="text-sm font-medium">Skills & Interests:</p>
                <div className="flex flex-wrap gap-2">
                  {interest.skills.map((skill, skillIndex) => (
                    <Badge key={skillIndex} variant="secondary" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-xl mb-4">Where Art Meets Athletics</h3>
            <p className="text-muted-foreground leading-relaxed">
              My creative interests aren't separate from my athletic background—they're intertwined. 
              The rhythm of running influences my dancing, the focus required for long distances 
              sharpens my sketching, and the breath control from athletics enhances my singing. 
              Together, they create a holistic approach to self-expression and personal growth.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}