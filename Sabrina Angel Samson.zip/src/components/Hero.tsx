import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-secondary/10 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-2">
              <h1 className="text-4xl md:text-6xl">
                Hi, I'm <span className="text-primary">Sabrina</span>
              </h1>
              <p className="text-xl text-muted-foreground">
                Student • Artist • Runner • Dreamer
              </p>
            </div>
            
            <p className="text-lg leading-relaxed max-w-2xl">
              A 21-year-old creative soul from Lucena City, Philippines, blending artistic passion 
              with athletic discipline. From competitive running to creative arts, I bring dedication 
              and curiosity to everything I pursue.
            </p>
            
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">Runner</Badge>
              <Badge variant="secondary">Artist</Badge>
              <Badge variant="secondary">Student</Badge>
              <Badge variant="secondary">Dancer</Badge>
              <Badge variant="secondary">Singer</Badge>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}>
                Learn More About Me
              </Button>
              <Button variant="outline" size="lg" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
                Get In Touch
              </Button>
            </div>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="w-80 h-80 md:w-96 md:h-96 rounded-full overflow-hidden border-4 border-primary/20 shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1758684051112-3df152ce3256?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwcnVubmVyJTIwbWFyYXRob24lMjBmaW5pc2glMjBsaW5lfGVufDF8fHx8MTc1OTIzOTIwOXww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Sabrina - Student and Runner"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-full shadow-lg">
                🏃‍♀️ Half Marathon Finisher
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}