import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

export function About() {
  return (
    <section id="about" className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">About Me</h2>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-primary/5 to-secondary/10 rounded-lg p-8 md:p-12">
            <div className="space-y-6">
              <p className="text-lg leading-relaxed text-muted-foreground">
                My name is Sabrina, and I'm a 21-year-old student living in Lucena City. I'm a knowledgeable person with many creative interests, including sketching, drawing, singing, and dancing. My family life is tightly woven with my past on the road; I'm one of two daughters to my mom, Ella, a housewife, and my stepdad, Joe, who works at IBM. My sister, Janieya, works at Optum.
              </p>
              
              <p className="text-lg leading-relaxed text-muted-foreground">
                We are a family of runners—our parents actually served as our trainers for the long-distance races. While they now live in the US and I stay here in the Philippines with my grandfather, Federico, we all shared the experience of those marathons, where I completed up to a half-marathon (21km) and even placed 3rd in a 10km run. Although academics led me to step back from competitive racing, running remains a cherished hobby.
              </p>
              
              <p className="text-lg leading-relaxed text-muted-foreground">
                Now, since we all stopped running competitively, our shared family passion has shifted to traveling together. I bring the discipline and knowledge from my athletic past into everything I do as a student today.
              </p>
            </div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <Card className="p-6 space-y-4 text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-xl mx-auto">
                🎨
              </div>
              <h3>Creative Interests</h3>
              <div className="flex flex-wrap gap-2 justify-center">
                <Badge variant="secondary">Sketching</Badge>
                <Badge variant="secondary">Drawing</Badge>
                <Badge variant="secondary">Singing</Badge>
                <Badge variant="secondary">Dancing</Badge>
              </div>
            </Card>
            
            <Card className="p-6 space-y-4 text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-xl mx-auto">
                🏃‍♀️
              </div>
              <h3>Athletic Achievements</h3>
              <div className="space-y-2">
                <Badge variant="outline">3rd Place - 10km</Badge>
                <Badge variant="outline">Half Marathon Finisher</Badge>
              </div>
            </Card>
            
            <Card className="p-6 space-y-4 text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-xl mx-auto">
                👨‍👩‍👧‍👧
              </div>
              <h3>Family Heritage</h3>
              <div className="space-y-2">
                <Badge variant="outline">Cross-Continental</Badge>
                <Badge variant="outline">Running Legacy</Badge>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}